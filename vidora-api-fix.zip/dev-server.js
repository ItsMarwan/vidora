import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = __dirname;
const host = process.env.HOST || '127.0.0.1';
const port = Number(process.env.PORT || 3000);

const mimeTypes = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
};

function getMimeType(filePath) {
  return mimeTypes[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
}

function sendJson(res, statusCode, payload, headers = {}) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(JSON.stringify(payload));
}

function createResponse(req, res) {
  const state = {
    statusCode: 200,
    headers: {},
    finished: false,
  };

  return {
    setHeader(name, value) {
      state.headers[name] = String(value);
    },
    status(code) {
      state.statusCode = code;
      return this;
    },
    json(payload) {
      if (state.finished) return;
      state.headers['Content-Type'] = 'application/json; charset=utf-8';
      state.headers['Cache-Control'] = 'no-store';
      state.finished = true;
      res.writeHead(state.statusCode, state.headers);
      res.end(JSON.stringify(payload));
    },
    send(body) {
      if (state.finished) return;
      state.finished = true;
      if (typeof body === 'object' && body !== null && !Buffer.isBuffer(body)) {
        state.headers['Content-Type'] = 'application/json; charset=utf-8';
        state.headers['Cache-Control'] = 'no-store';
        res.writeHead(state.statusCode, state.headers);
        res.end(JSON.stringify(body));
        return;
      }
      if (typeof body === 'undefined') {
        res.writeHead(state.statusCode, state.headers);
        res.end();
        return;
      }
      res.writeHead(state.statusCode, state.headers);
      res.end(String(body));
    },
    end(body) {
      if (state.finished) return;
      state.finished = true;
      res.writeHead(state.statusCode, state.headers);
      res.end(body);
    },
  };
}

async function resolveHandler(pathname) {
  const parts = pathname.split('/').filter(Boolean);
  if (parts[0] !== 'api') return null;

  if (pathname === '/api/config') return './api/config.js';
  if (pathname === '/api/tmdb') return './api/tmdb.js';
  if (pathname === '/api/party') return './api/party.js';

  return null;
}

async function serveApi(req, res, pathname, query) {
  const handlerPath = await resolveHandler(pathname);
  if (!handlerPath) {
    return sendJson(res, 404, { error: 'Not found' });
  }

  try {
    const moduleUrl = pathToFileURL(path.join(rootDir, handlerPath)).href;
    const module = await import(moduleUrl);
    const handler = module.default || module;
    const request = {
      method: req.method,
      url: req.url,
      headers: req.headers,
      query,
      body: null,
      socket: { remoteAddress: req.socket.remoteAddress },
    };

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      const chunks = [];
      for await (const chunk of req) {
        chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
      }
      const raw = Buffer.concat(chunks).toString('utf8');
      if (raw) {
        try { request.body = JSON.parse(raw); }
        catch { request.body = raw; }
      }
    }

    const response = createResponse(req, res);
    await handler(request, response);
  } catch (error) {
    console.error('API handler error:', error);
    sendJson(res, 500, { error: 'Internal server error' });
  }
}

function serveStatic(req, res, pathname) {
  const safePath = pathname === '/' ? '/index.html' : pathname;
  const filePath = path.join(rootDir, safePath);

  if (!filePath.startsWith(rootDir)) {
    sendJson(res, 403, { error: 'Forbidden' });
    return;
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      const fallbackPath = path.join(rootDir, 'index.html');
      fs.readFile(fallbackPath, (fallbackErr, data) => {
        if (fallbackErr) {
          sendJson(res, 404, { error: 'Not found' });
          return;
        }
        res.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8',
          'Cache-Control': 'no-store',
        });
        res.end(data);
      });
      return;
    }

    fs.readFile(filePath, (readErr, data) => {
      if (readErr) {
        sendJson(res, 500, { error: 'Could not read file' });
        return;
      }
      res.writeHead(200, {
        'Content-Type': getMimeType(filePath),
        'Cache-Control': 'no-store',
      });
      res.end(data);
    });
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  const pathname = decodeURIComponent(url.pathname);
  const query = Object.fromEntries(url.searchParams.entries());

  if (pathname.startsWith('/api/')) {
    await serveApi(req, res, pathname, query);
    return;
  }

  serveStatic(req, res, pathname);
});

server.listen(port, host, () => {
  console.log(`Vidora dev server running at http://${host}:${port}`);
});
